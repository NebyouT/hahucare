<?php

return [
    'lbl_name' => 'ማስገቢያ ማስገቢያ ቆይታ',
];
