<?php

return [
    'lbl_order_prefix' => 'የትእዛዝ ቅድመ ቅጥያ',
    'lbl_order_starts' => 'ትእዛዝ ይጀምራል',
    'lbl_spacial_note' => 'የቦታ ማስታወሻ',
    'spacial_note'=>'የቦታ ማስታወሻዎን ያስገቡ',

];
