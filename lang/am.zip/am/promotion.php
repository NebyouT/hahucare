<?php

return [
    'title' => 'ማስተዋወቂያዎች',
    'singular_title' => 'ማስተዋወቂያዎች',
    'lbl_status'=>'ሁኔታ',
    'lbl_expired'=>'ጊዜው አልፎበታል።',
    'lbl_name' => 'ስም',
    'lbl_action'=>'ድርጊት',
    'description' => 'መግለጫ',
    'start_datetime'=>'የመጀመሪያ ቀን ሰዓት',
    'end_datetime'=>'የመጨረሻ ቀን ሰዓት',
    'coupon_code'=>'የኩፖን ኮድ',
    'coupon_type'=>'የኩፖን አይነት',
    'number_of_coupon'=>'የኩፖን ብዛት',
    'percent_or_fixed'=>'መቶኛ ወይም ቋሚ',
    'discount_percentage'=>'የቅናሽ መቶኛ',
    'discount_amount'=>'የቅናሽ መጠን',
    'use_limit'=>'ገደብ ተጠቀም',
    'coupon_title'=>'ኩፖኖች',
    'user'=>'ተጠቃሚ',
    'timezone'=>'የሰዓት ሰቅ',
    'value'=>'ዋጋ',






];
