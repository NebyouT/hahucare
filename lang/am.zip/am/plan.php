<?php

return [
    'title' => 'የምዝገባ ዕቅዶች',
    'singular_title' => 'የደንበኝነት ምዝገባዎች እቅድ',
    'lbl_name' => 'ስም',
    'lbl_type' => 'ዓይነት',
    'lbl_duration' => 'ቆይታ',
    'lbl_amount' => 'መጠን',
    'lbl_plan_limitation' => 'የእቅድ ገደብ',
    'lbl_description' => 'መግለጫ',
    'lbl_status' => 'ሁኔታ',
    'lbl_select_limitation' => 'ገደብ ይምረጡ',
    'lbl_set_limit' => 'ገደብ አዘጋጅ',
];
