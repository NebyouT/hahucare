<?php

return [
    'lbl_quick_booking' => 'ፈጣን ቦታ ማስያዝ',
    'lbl_shared_link' => 'የተጋራ አገናኝ',
    'is_enable_all' => 'ሁሉም',
    'clinic' => 'ክሊኒክ',
    'lbl_verify'=>'አረጋግጥ',
    'lbl_first_name'=>'የመጀመሪያ ስም',
    'lbl_last_name'=>'የአያት ስም',
    'lbl_phone_number'=>'ስልክ ቁጥር',
    'lbl_gender'=>'ጾታ'
];
