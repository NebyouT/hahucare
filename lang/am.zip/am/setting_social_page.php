<?php

return [
    'lbl_fb_url' => 'የፌስቡክ ገጽ URL (facebook_url)',
    'lbl_twitter_url' => 'የትዊተር መገለጫ URL (twitter_url)',
    'lbl_insta_url' => 'የኢንስታግራም መለያ URL (instagram_url)',
    'lbl_linkedin_url' => 'LinkedIn URL (linkedin_url)',
    'lbl_youtube_url' => 'የዩቲዩብ ቻናል URL (youtube_url)',
];
