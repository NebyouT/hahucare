<?php

return [
    'title' => 'ግዛቶች',
    'singule_title' => 'ግዛት',
];
