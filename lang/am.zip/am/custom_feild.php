<?php

return [
    'lbl_add' => 'ብጁ መስክን ያክሉ',
    'lbl_edit' => 'CustomField ውሂብን ያርትዑ',
    'lbl_module' => 'ሞጁል',
    'lbl_label' => 'መለያ',
    'lbl_type' => 'ዓይነት',
    'lbl_is_required' => 'ያስፈልጋል',
    'lbl_allow_table_view' => 'በሰንጠረዥ እይታ ውስጥ ወደ ውጭ መላክ ፍቀድ',
    'lbl_show_table_view' => 'በሠንጠረዥ እይታ ውስጥ አሳይ',
    'lbl_sr_no' => 'Sr.አይ',
    'lbl_modules' => 'ሞጁሎች',
    'lbl_field_lable' => 'የመስክ ላብል',
    'lbl_action' => 'ድርጊት',
    'lbl_is_value' => 'ዋጋ',

];
