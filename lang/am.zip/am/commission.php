<?php

return [
    'lbl_title' => 'ርዕስ',
    'lbl_value' => 'የኮሚሽኑ ዋጋ',
    'lbl_commission_type' => 'የኮሚሽኑ ዓይነት',
    'lbl_add_commission' => 'ኮሚሽን ጨምር',
    'lbl_edit_commission' => 'የኮሚሽኑ ውሂብ ያርትዑ',
    'lbl_sr_no' => 'Sr.አይ',
    'lbl_action' => 'ድርጊት',
    'lbl_commission_type' => 'የኮሚሽኑ ዓይነት',
    'lbl_type' => 'ዓይነት',
];
