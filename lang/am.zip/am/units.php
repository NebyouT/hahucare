<?php

return [
    'title' => 'ክፍሎች',
    'singular_title' => 'ክፍል',
];
