<?php

return [
    'lbl_title' => 'ርዕስ',
    'lbl_add_menu' => 'ምናሌን ያክሉ',
    'lbl_edit_menu' => 'ምናሌን ያርትዑ',
    'lbl_icon' => 'አዶ',
    'lbl_menu_type' => 'የምናሌ አይነት',
    'lbl_is_route' => 'የመተግበሪያ ራውተር',
    'lbl_url' => 'URL',
    'lbl_target' => 'በትር ውስጥ ክፈት',
    'lbl_status' => 'ሁኔታ',
    'lbl_disable' => 'ተሰናክሏል።',

];
