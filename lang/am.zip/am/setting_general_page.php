<?php

return [
    'lbl_app' => 'የንግድ ስም',
    'lbl_footer' => 'የግርጌ ጽሑፍ',
    'lbl_copyright' => 'የቅጂ መብት ጽሑፍ',
    'lbl_uitext' => 'የዩአይ ጽሑፍ',
    'lbl_contact_no' => 'የእውቂያ ቁጥር',
    'lbl_inquiry_email' => 'ኢሜይል',
    'lbl_site_description' => 'አጭር መግለጫ',
    'business_add' => 'አድራሻ',
    'branding' => 'የምርት ስም ማውጣት',
    'lbl_doctor_app' => 'የዶክተር መተግበሪያ ስም',
    'lbl_user_app' => 'የተጠቃሚ መተግበሪያ ስም',
];
