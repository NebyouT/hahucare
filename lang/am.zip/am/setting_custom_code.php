<?php

return [
    'lbl_css_name' => 'ብጁ የሲኤስ ኮድ (ብጁ_css_ብሎክ)',
    'lbl_js_name' => 'ብጁ Js ኮድ (ብጁ_js_ብሎክ)',
];
