<?php

return [
    'lbl_email' => 'ኢሜል (ኢሜል)',
    'lbl_driver' => 'የፖስታ ሹፌር',
    'lbl_host' => 'የፖስታ አስተናጋጅ',
    'lbl_port' => 'የፖስታ ወደብ',
    'lbl_encryption' => 'የደብዳቤ ምስጠራ',
    'lbl_username' => 'የደብዳቤ ተጠቃሚ ስም',
    'lbl_password' => 'የይለፍ ቃል',
    'lbl_mail' => 'ደብዳቤ ከ',
    'lbl_from_name' => 'ከስም',
];
