<?php

return [
    'title' => 'አገሮች',
    'singular_title' => 'ሀገር',
];
