<?php

return [
    'lbl_name' => 'ጉግል አናሌቲክስ',
];
