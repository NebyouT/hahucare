<?php

return [
    'lbl_name' => 'አገልግሎት አቅራቢን ይምረጡ',
    'lbl_add_day_off' => 'የእረፍት ቀን ጨምር',
    'lbl_add_break' => 'እረፍት ጨምር',
    'lbl_break' => 'መስበር',
];
