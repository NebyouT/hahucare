<?php

return [
    'title' => 'ሎጂስቲክስ',

];
