<?php

return [
    'title' => 'ቋሚ',
    'lbl_type' => 'ዓይነት',
    'lbl_name' => 'ስም',
    'lbl_value' => 'ዋጋ',
    'lbl_sub_type' => 'ንዑስ ዓይነት',
    'lbl_sequence' => 'ቅደም ተከተል',
    'lbl_status' => 'ሁኔታ',
];
