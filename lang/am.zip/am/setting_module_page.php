<?php

return [
    'lbl_soap' => 'ሳሙና',
    'lbl_body_chart' => 'የሰውነት ገበታ',
    'lbl_telemed_setting' => 'የቴሌሜድ ቅንብር',
    'lbl_multi_vendor' => 'ባለብዙ ሻጭ',
    'lbl_blog' => 'ብሎግ',
    'lbl_problem' => 'ችግር',
    'lbl_observation' => 'ምልከታ',
    'lbl_note' => 'ማስታወሻ',
    'lbl_prescription' => 'ማዘዣ',
    'lbl_encounter_module' => 'መገናኘት',
    'module_setting'=>'ሞጁል ቅንብር',
];
