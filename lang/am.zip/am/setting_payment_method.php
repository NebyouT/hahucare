<?php

return [
    'lbl_razorpay' => 'Razorpay',
    'lbl_secret_key' => 'ሚስጥራዊ ቁልፍ',
    'lbl_app_key' => 'የመተግበሪያ ቁልፍ',
    'lbl_stripe' => 'ጭረት',
    'lbl_paystack' => 'ክፍያ',
    'lbl_paypal' => 'Paypal',
    'lbl_flutterwave' => 'Flutterwave',
    'lbl_client_id' => 'የደንበኛ መታወቂያ',
    'lbl_app_id'=>'የመተግበሪያ መታወቂያ',
    'lbl_merchant_id'=>'የነጋዴ መታወቂያ',
    'lbl_salt_key'=>'የጨው ቁልፍ',
    'lbl_salt_index'=>'የጨው መረጃ ጠቋሚ',
    'cinet_siteid' => 'የጣቢያ መታወቂያ',
    'cinet_apikey' => 'አፒ ቁልፍ',
    'cinet_secretkey' => 'ሚስጥራዊ ቁልፍ',
    'sadad_id' => 'ሳዳድ መታወቂያ',
    'sadad_key' => 'ሳዳድ ቁልፍ',
    'sadad_domain' => 'ሳዳድ ጎራ', 
    
    'lbl_phone_pay'=>'PhonePe', 
    'lbl_airtel_money' => 'የኤርቴል ገንዘብ',
    'lbl_midtrans'=>'ሚድትራንስ',
    'lbl_cinet' => 'ሲኔት',
    'lbl_sadad' => 'ሳዳድ',
];
