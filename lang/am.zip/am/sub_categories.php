<?php

return [
    'title' => 'ንዑስ ምድቦች',

];
