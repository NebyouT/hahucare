<?php

return [
    'title' => 'ትዕዛዞች',
];
