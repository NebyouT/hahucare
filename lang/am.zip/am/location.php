<?php

return [
    'title' => 'አካባቢ',
];
