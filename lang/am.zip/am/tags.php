<?php

return [
    'title' => 'መለያ',
];
