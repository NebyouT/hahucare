<?php

return [
    'title' => 'ልዩነቶች',
    'singular_title' => 'ልዩነት',
];
