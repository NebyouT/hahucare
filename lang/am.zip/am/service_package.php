<?php

return [
    'title' => 'የአገልግሎት አገልግሎት ጥቅል',
    'singular_title' => 'የአገልግሎት አገልግሎት ጥቅል',
    'lbl_select_staff' => 'ሠራተኞችን ይምረጡ',
    'lbl_package_type' => 'የጥቅል ዓይነትን ይምረጡ',
    'lbl_category' => 'ምድብ',
    'lbl_sub_category' => 'ንዑስ ምድብ',
    'lbl_select_service' => 'አገልግሎት ይምረጡ',
    'lbl_start_at' => 'ጀምር በ',
    'lbl_End At' => 'መጨረሻ በ',
    'lbl_price' => 'ዋጋ',
    'lbl_image' => 'ምስል',
    'lbl_description' => 'መግለጫ',
    'lbl_name' => 'ስም',
    'lbl_status' => 'ሁኔታ',
];
