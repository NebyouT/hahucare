<?php

return [
    'title' => 'የማጓጓዣ ዞን',
    'lbl_name' => 'ስም',
    'logistic' => 'ሎጂስቲክስ',
    'cities' => 'ከተሞች',
    'state' => 'ግዛት',
    'country' => 'ሀገር',
    'standard_delivery_charge' => 'መደበኛ የመላኪያ ክፍያ',
    'standard_delivery_time' => 'መደበኛ የመላኪያ ጊዜ',
];
