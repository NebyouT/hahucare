<?php

return [
    'title' => 'ጠቃሚ ነገሮች',
    'singular_title' => 'ጠቃሚ',
    'lbl_profile'=>'መገለጫ',
    'lbl_height_CM'=>'ቁመት ሴንቲ ሜትር',
    'lbl_weight_KG'=>'ክብደት ኪ.ግ',
    'lbl_height_Inch'=>'ቁመት ኢንች',
    'lbl_bmi'=>'BMI',
    'lbl_tbf'=>'ቲቢኤፍ',
    'lbl_vfi'=>'ቪኤፍአይ',
    'lbl_tbw'=>'ቲቢደብሊው',
    'lbl_sm'=>'ኤስ.ኤም',
    'lbl_bmc'=>'ቢኤምሲ',
    'lbl_bmr'=>'BMR',
    'lbl_height_meter'=>'ቁመት ሜትር',




 ];
