<?php

return [
    'title' => 'የእቅድ ገደብ',
    'lbl_name' => 'ስም',
    'lbl_status' => 'ሁኔታ',
    'lbl_set_limit' => 'ገደብ አዘጋጅ',
];
