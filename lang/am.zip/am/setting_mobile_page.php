<?php

return [
    'lbl_primary' => 'ዋና',
    'lbl_secondary' => 'ሁለተኛ ደረጃ',
    'lbl_app_id' => 'የመተግበሪያ መታወቂያ',
    'lbl_security' => 'የመተግበሪያ ደህንነት',
];
