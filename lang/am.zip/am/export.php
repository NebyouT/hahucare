<?php

return[
    'title' => 'ውሂብ ወደ ውጪ ላክ',
    'lbl_date' => 'ቀን',
    'lbl_select_file_type' => 'የፋይል አይነትን ይምረጡ',
    'lbl_select_columns' => 'አምዶችን ይምረጡ',
    'download' => 'አውርድ',
    'cancel' => 'ሰርዝ',
    'import' => 'አስመጣ',
];
