<?php

return [
    'title' => 'ክሊኒክ አስተዳዳሪ',
    'singular_title' => 'ክሊኒክ አስተዳዳሪ',
    'lbl_profile_image' => 'የመገለጫ ምስል',
    'lbl_first_name' => 'የመጀመሪያ ስም',
    'lbl_last_name' => 'የአያት ስም',
    'lbl_Email' => 'ኢሜይል',
    'lbl_phone_number' => 'ስልክ ቁጥር',
    'lbl_gender' => 'ጾታ',
    'lbl_status' => 'ሁኔታ',
    'lbl_verification_status' => 'የማረጋገጫ ሁኔታ',
    'lbl_blocked' => 'ታግዷል',
    'msg_verified' => 'የተረጋገጠ',
    'msg_unverified' => 'ማረጋገጥ ያስፈልጋል',
    'lbl_action' => 'ድርጊት',
    'lbl_date_of_birth'=>'የተወለደበት ቀን',
    'google_blocked' => 'የክሊኒክ አስተዳዳሪ ታግዷል',
    'google_unblocked' => 'የክሊኒክ አስተዳዳሪ ታግዷል',
    'vendor_verify' => 'የክሊኒክ አስተዳዳሪ ተረጋግጧል',
    'vendor_status' => 'የክሊኒክ አስተዳዳሪ ሁኔታ ተዘምኗል',
    'vendor_delete' => 'የክሊኒክ አስተዳዳሪ በተሳካ ሁኔታ ተሰርዟል።',
    'lbl_select_system_service' => 'የስርዓት አገልግሎትን ይምረጡ',
    'new_vendor' => 'የክሊኒክ አስተዳዳሪ በተሳካ ሁኔታ ተቀምጧል',
    'update_vendor' => 'የክሊኒክ አስተዳዳሪ በተሳካ ሁኔታ ዘምኗል',
    'delete_vendor' => 'የክሊኒክ አስተዳዳሪ በተሳካ ሁኔታ ተሰርዟል።',

];
