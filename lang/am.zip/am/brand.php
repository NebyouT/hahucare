<?php

return [
    'title' => 'ብራንዶች',
    'singular_title' => 'የምርት ስም',
    'name' => 'ስም',
    'updated_at' => 'የዘመነ በ',
    'brand_list' => 'የምርት ስም ዝርዝር',
];
