<?php

return [
    'title' => 'ልጥፎች',
    'singular_title' => 'ለጥፍ',
    'lbl_image' => 'ምስል',
    'lbl_name' => 'ስም',
    'lbl_is_featured' => 'ተለይቶ የቀረበ',
    'lbl_status' => 'ሁኔታ',
    'lbl_action' => 'ድርጊት',
    'lbl_information' => 'መረጃ',
    'lbl_short_description' => 'አጭር መግለጫ',
    'lbl_description' => 'መግለጫ',
    'lbl_select_employee' => 'ተቀጣሪ ይምረጡ',
    'lbl_categories' => 'ምድብ',
    'lbl_type' => 'ዓይነት',
    'lbl_published_at' => 'የታተመ በ',
    'seo' => 'ሴኦ',
    'seo_meta_title' => 'የ Seo Meta ርዕስ',
    'seo_meta_description' => 'የ Seo Meta መግለጫ',
    'seo_meta_open_graph_url' => 'የ Seo Meta ግራፍ ዩአርኤል ክፈት',
    'seo_meta_keywords' => 'የ Seo Meta ቁልፍ ቃላት',
    'seo_meta_open_graph_image' => 'የ Seo Meta ክፍት የግራፍ ምስል'

 ];