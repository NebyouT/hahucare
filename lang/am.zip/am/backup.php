<?php

return [
    'title' => 'ምትኬ',
    'age' => 'ዕድሜ',
    'file' => 'ፋይል',
    'size' => 'መጠን',
    'download' => 'አውርድ',
    'delete' => 'ሰርዝ',
];
