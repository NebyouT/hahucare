<?php

return [
    'title' => 'ግብር',
];
