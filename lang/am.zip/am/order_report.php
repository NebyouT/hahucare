<?php

return [
    'title' => 'የትዕዛዝ ሪፖርት',
    'payment_status' => 'የክፍያ ሁኔታ',
    'paid' => 'የተከፈለ',
    'unpaid' => 'ያልተከፈለ',
    'delivery_status' => 'የመላኪያ ሁኔታ',
    'order_placed' => 'ትእዛዝ ተሰጥቷል።',
    'pending' => 'በመጠባበቅ ላይ',
    'processing' => 'በማቀነባበር ላይ',
    'delivered' => 'ደረሰ',
    'cancelled' => 'ተሰርዟል።',
];
