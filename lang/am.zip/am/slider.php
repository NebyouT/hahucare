<?php

return [
    'title' => 'የመተግበሪያ ባነር',
    'singular_title' => 'የመተግበሪያ ባነር',
    'lbl_name' => 'ስም',
    'lbl_link' => 'URL',
    'lbl_type' => 'ዓይነት',
    'lbl_link_id' => 'የአገናኝ መታወቂያ',
    'lbl_status' => 'ሁኔታ',
    'lbl_file_url' => 'የባህሪ ምስል',
    'lbl_action' => 'ድርጊት',
    'create_title' => 'የመተግበሪያ ባነር ፍጠር',
    'edit_title' => 'የመተግበሪያ ሰንደቅን ያርትዑ',
    'slider_created_successfully' => 'የመተግበሪያ ባነር በተሳካ ሁኔታ ተፈጥሯል!',
    'slider_updated_successfully' => 'የመተግበሪያ ባነር በተሳካ ሁኔታ ዘምኗል!',
];
