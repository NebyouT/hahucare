<?php

return [
    'lbl_site_name' => 'ሜታ ጣቢያ ስም (ሜታ_site_ስም)',
    'lbl_description' => 'ሜታ መግለጫ (ሜታ_ገለፃ)',
    'lbl_keyword' => 'ሜታ ቁልፍ ቃል (ሜታ_ቁልፍ ቃል)',
    'lbl_image' => 'ሜታ ምስል (ሜታ_ምስል)',
    'lbl_fb_app_id' => 'ሜታ Facebook መተግበሪያ መታወቂያ (ሜታ_fb_app_id)',
    'lbl_twitter_site' => 'ሜታ ትዊተር የጣቢያ መለያ (meta_twitter_site)',
    'lbl_twitter_creator' => 'ሜታ ትዊተር ፈጣሪ መለያ (meta_twitter_creator)',
];
