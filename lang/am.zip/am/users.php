<?php

return [
    'title' => 'ተጠቃሚዎች',
    'account_crdential' => 'የመለያ ምስክርነቶች ለተጠቃሚ ተልከዋል።',
    'user_created' => 'ተጠቃሚ በተሳካ ሁኔታ ተፈጥሯል።',
    'lbl_old_password' => 'የድሮ የይለፍ ቃል',
    'lbl_new_password' => 'አዲስ የይለፍ ቃል',
    'lbl_confirm_password' => 'አዲስ የይለፍ ቃል ያረጋግጡ',
    'address_store' => 'የተጠቃሚ አድራሻ ተከማችቷል።',
    'user_not_found' => 'ተጠቃሚ አልተገኘም።',
    'address_list' => 'የተጠቃሚ አድራሻ ዝርዝር',
    'address_not_found' => 'አድራሻ አልተገኘም።',
    'address_deleted' => 'አድራሻ ተሰርዟል።',
    'address_updated' => 'አድራሻ ተዘምኗል',
    'change_password'=>'የይለፍ ቃል ቀይር',
    'new_password' => 'አዲስ የይለፍ ቃል ያስገቡ',
    'confirm_password' => 'አዲስ የይለፍ ቃል ያረጋግጡ',
];
