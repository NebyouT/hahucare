<?php

return [
    'lbl_app'=>'መተግበሪያ',
    'lbl_doctor_app'=>'ዶክተር መተግበሪያ',
    'lbl_user_app'=>'የተጠቃሚ መተግበሪያ',
    'lbl_contact_no'=>'የእውቂያ ቁጥር',
    'lbl_inquiry_email'=>'የጥያቄ ኢሜል',
    'lbl_site_description'=>'የጣቢያ መግለጫ',
    'business_add'=>'ንግድ አክል',
    'lbl_shop_number'=>'የሱቅ ቁጥር',
    'lbl_landmark'=>'lbl_landmark',
    'lbl_country'=>'ሀገር',
    'lbl_state'=>'ግዛት',
    'lbl_city'=>'ከተማ',
    'lbl_postal_code'=>'የፖስታ መላኪያ ኮድ',
    'lbl_lat'=>'ኬክሮስ',
    'lbl_long'=>'ኬንትሮስ',
    'branding'=>'የምርት ስም ማውጣት',
    'dark_mini_logo'=>'ጨለማ ሚኒ አርማ',

];
