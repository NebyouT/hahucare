<?php

return [
    'title' => 'ግብር',
    'lbl_title' => 'ርዕስ',
    'lbl_value' => 'ዋጋ',
    'lbl_select_type' => 'ዓይነት ይምረጡ',
    'lbl_Type' => 'ዓይነት',
    'lbl_status' => 'ሁኔታ',
    'lbl_action' => 'ድርጊት',
    'lbl_module_type' => 'የሞዱል ዓይነት',
    'lbl_tax_type' => 'የግብር ዓይነት',
    'lbl_tax_category' => 'የግብር ምድብ',

];
