<?php

return [
    'title' => 'ከተሞች',
    'singular_title' => 'ከተማ',
    'state_name' => 'የግዛት ስም',
    'state' => 'ግዛት',
];
