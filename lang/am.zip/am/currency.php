<?php

return [
    'title' => 'አገሮች',
    'lbl_edit' => 'ምንዛሬን ያርትዑ',
    'lbl_add' => 'አዲስ ምንዛሪ ጨምር',
    'lbl_currency_name' => 'የምንዛሬ ስም',
    'lbl_currency_symbol' => 'የምንዛሬ ምልክት',
    'lbl_currency_code' => 'የምንዛሬ ኮድ',
    'lbl_is_primary' => 'ቀዳሚ ነው።',
    'lbl_currency_position' => 'የምንዛሬ አቀማመጥ',
    'lbl_thousand_separatorn' => 'ሺህ መለያየት',
    'lbl_decimal_separator' => 'የአስርዮሽ መለያየት',
    'lbl_number_of_decimals' => 'የአስርዮሽ ብዛት',
    'lbl_ID' => 'መታወቂያ',
    'lbl_action' => 'ድርጊት',
    'currency_format' => 'የምንዛሬ ቅርጸት ቅንብሮች',
    'primary_msg' => 'ቢያንስ አንድ ዋና ገንዘብ ሊኖርዎት ይገባል።',
    'example'=>'ለምሳሌ',
];
