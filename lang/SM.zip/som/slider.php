<?php

return [
    'title' => 'Banner Appka',
    'singular_title' => 'Banner Appka',
    'lbl_name' => 'Magaca',
    'lbl_link' => 'URL',
    'lbl_type' => 'Nooca',
    'lbl_link_id' => 'Xidhiidhka aqoonsiga',
    'lbl_status' => 'Xaalada',
    'lbl_file_url' => 'Muuqaalka Muuqaalka',
    'lbl_action' => 'Ficil',
    'create_title' => 'Abuur Banner App',
    'edit_title' => 'Wax ka beddel Banner Appka',
    'slider_created_successfully' => 'Banner App-ka ayaa si guul leh loo sameeyay!',
    'slider_updated_successfully' => 'Banner Appka si guul leh ayaa loo cusboonaysiiyay!',
];
