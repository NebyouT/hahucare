<?php

return[
    'title' => 'Dhoofinta Xogta',
    'lbl_date' => 'Taariikhda',
    'lbl_select_file_type' => 'Dooro Nooca Faylka',
    'lbl_select_columns' => 'Dooro Tiirarka',
    'download' => 'Download',
    'cancel' => 'Jooji',
    'import' => 'Soo dejinta',
];
