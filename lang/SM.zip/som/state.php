<?php

return [
    'title' => 'Gobolada',
    'singule_title' => 'Gobolka',
];
