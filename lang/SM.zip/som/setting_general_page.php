<?php

return [
    'lbl_app' => 'Magaca Ganacsiga',
    'lbl_footer' => 'Footer Text',
    'lbl_copyright' => 'Qoraalka Xuquuqda Daabacaadda',
    'lbl_uitext' => 'Qoraalka UI',
    'lbl_contact_no' => 'Lambarka Xiriirka',
    'lbl_inquiry_email' => 'iimaylka',
    'lbl_site_description' => 'Sharaxaad Gaaban',
    'business_add' => 'Cinwaanka',
    'branding' => 'Calaamadaynta',
    'lbl_doctor_app' => 'Magaca App-ka dhakhtarka',
    'lbl_user_app' => 'Magaca App-ka isticmaalaha',
];
