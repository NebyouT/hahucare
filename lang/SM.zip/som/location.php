<?php

return [
    'title' => 'Goobta',
];
