<?php

return [
    'lbl_name' => 'Dooro Bixiyaha Adeegga',
    'lbl_add_day_off' => 'Ku dar maalin fasax',
    'lbl_add_break' => 'Ku dar nasashada',
    'lbl_break' => 'Nasasho',
];
