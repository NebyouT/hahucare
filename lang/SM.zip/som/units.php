<?php

return [
    'title' => 'Unugyo',
    'singular_title' => 'Unug',
];
