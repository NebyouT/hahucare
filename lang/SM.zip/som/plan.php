<?php

return [
    'title' => 'Qorshayaasha Diiwaangelinta',
    'singular_title' => 'Qorshaha Isdiiwaangelinta',
    'lbl_name' => 'Magaca',
    'lbl_type' => 'Nooca',
    'lbl_duration' => 'Muddada',
    'lbl_amount' => 'Qadarka',
    'lbl_plan_limitation' => 'Xadaynta Qorshaha',
    'lbl_description' => 'Sharaxaada',
    'lbl_status' => 'Xaalada',
    'lbl_select_limitation' => 'Dooro Xaddidan',
    'lbl_set_limit' => 'Deji Xadka',
];
