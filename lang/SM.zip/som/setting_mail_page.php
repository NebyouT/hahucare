<?php

return [
    'lbl_email' => 'Iimayl (email)',
    'lbl_driver' => 'Dareewalka Boostada',
    'lbl_host' => 'Martigeliyaha Boostada',
    'lbl_port' => 'Dekedda Boostada',
    'lbl_encryption' => 'Sireeynta boostada',
    'lbl_username' => 'Magaca isticmaalaha boostada',
    'lbl_password' => 'erayga sirta ah',
    'lbl_mail' => 'Boostada Ka socota',
    'lbl_from_name' => 'Ka Magaca',
];
