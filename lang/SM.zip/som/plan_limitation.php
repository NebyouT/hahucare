<?php

return [
    'title' => 'Xadaynta Qorshaha',
    'lbl_name' => 'Magaca',
    'lbl_status' => 'Xaalada',
    'lbl_set_limit' => 'Deji Xadka',
];
