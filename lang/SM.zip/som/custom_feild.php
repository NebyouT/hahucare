<?php

return [
    'lbl_add' => 'Kudar CustomField',
    'lbl_edit' => 'Wax ka beddel xogta CustomField',
    'lbl_module' => 'Module',
    'lbl_label' => 'Summada',
    'lbl_type' => 'Nooca',
    'lbl_is_required' => 'Loo baahan yahay',
    'lbl_allow_table_view' => 'Oggolow dhoofinta muuqaalka miiska',
    'lbl_show_table_view' => 'Ku muuji muuqaalka miiska',
    'lbl_sr_no' => 'Sr. Maya',
    'lbl_modules' => 'Modules',
    'lbl_field_lable' => 'Field Lable',
    'lbl_action' => 'Ficil',
    'lbl_is_value' => 'Qiimaha',

];
