<?php

return [
    'title' => 'Kaabta',
    'age' => 'Da'da',
    'file' => 'Faylka',
    'size' => 'Cabbirka',
    'download' => 'Download',
    'delete' => 'Tirtir',
];
