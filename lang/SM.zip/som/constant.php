<?php

return [
    'title' => 'Joogto ah',
    'lbl_type' => 'Nooca',
    'lbl_name' => 'Magaca',
    'lbl_value' => 'Qiimaha',
    'lbl_sub_type' => 'Nooca hoose',
    'lbl_sequence' => 'isku xigxiga',
    'lbl_status' => 'Xaalada',
];
