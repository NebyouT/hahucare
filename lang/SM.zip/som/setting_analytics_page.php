<?php

return [
    'lbl_name' => 'Google Analytics',
];
