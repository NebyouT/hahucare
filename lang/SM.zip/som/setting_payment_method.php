<?php

return [
    'lbl_razorpay' => 'Razorpay',
    'lbl_secret_key' => 'Furaha Qarsoon',
    'lbl_app_key' => 'Furaha abka',
    'lbl_stripe' => 'Xarig',
    'lbl_paystack' => 'Lacag bixin',
    'lbl_paypal' => 'Paypal',
    'lbl_flutterwave' => 'Flutterwave',
    'lbl_client_id' => 'Aqoonsiga macmiilka',
    'lbl_app_id'=>'App Id',
    'lbl_merchant_id'=>'Id ganacsade',
    'lbl_salt_key'=>'Furaha milixda',
    'lbl_salt_index'=>'Tusmada milixda',
    'cinet_siteid' => 'Aqoonsiga goobta',
    'cinet_apikey' => 'Furaha Api',
    'cinet_secretkey' => 'Furaha Qarsoon',
    'sadad_id' => 'Sadaad Id',
    'sadad_key' => 'Sacad Key',
    'sadad_domain' => 'Sadad Domain', 
    
    'lbl_phone_pay'=>'PhonePe', 
    'lbl_airtel_money' => 'Lacagta Airtel',
    'lbl_midtrans'=>'Midtrans',
    'lbl_cinet' => 'Cinet',
    'lbl_sadad' => 'Sacad',
];
