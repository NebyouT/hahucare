<?php

return [
    'title' => 'Isticmaalayaasha',
    'account_crdential' => 'Aqoonsiga Koontada Loo Diray Isticmaalaha',
    'user_created' => 'Isticmaalaha Si Guul Ah Ayaa Loo Abuuray',
    'lbl_old_password' => 'Furaha hore',
    'lbl_new_password' => 'Furaha cusub',
    'lbl_confirm_password' => 'Xaqiiji erayga sirta ah ee cusub',
    'address_store' => 'Ciwaanka isticmaalaha waa la kaydiyay',
    'user_not_found' => 'Isticmaalaha Lama Helin',
    'address_list' => 'Liiska Ciwaanka Isticmaalaha',
    'address_not_found' => 'Ciwaanka Lama Helin',
    'address_deleted' => 'Ciwaanka waa la tirtiray',
    'address_updated' => 'Ciwaanka waa la cusboonaysiiyay',
    'change_password'=>'Beddel erayga sirta ah',
    'new_password' => 'Geli Password Cusub',
    'confirm_password' => 'Geli Xaqiiji Kelmad Cusub',
];
