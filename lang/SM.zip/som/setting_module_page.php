<?php

return [
    'lbl_soap' => 'SABUUN',
    'lbl_body_chart' => 'Jaantuska Jirka',
    'lbl_telemed_setting' => 'Dejinta Telemed',
    'lbl_multi_vendor' => 'Iibiyaha Badan',
    'lbl_blog' => 'Blog',
    'lbl_problem' => 'Dhib',
    'lbl_observation' => 'U fiirsashada',
    'lbl_note' => 'Ogow',
    'lbl_prescription' => 'Daawada',
    'lbl_encounter_module' => 'Kulanka',
    'module_setting'=>'Dejinta Module',
];
