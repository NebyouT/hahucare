<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Aqoonsigani kuma eka diiwaannadayada.',
    'password' => 'Furaha sirta ah ee la bixiyay waa khalad.',
    'throttle' => 'Isku dayo soo gal oo aad u badan Fadlan isku day marlabaad :ilbiriqsi gudahood.',
    'unauthenticated' => 'Aan la hubin',

];
