<?php

return [
    'title' => 'Noocyada',
    'singular_title' => 'Summada',
    'name' => 'Magaca',
    'updated_at' => 'La cusboonaysiiyay At',
    'brand_list' => 'Liiska Calaamadaha',
];
