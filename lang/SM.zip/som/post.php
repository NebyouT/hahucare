<?php

return [
    'title' => 'Qoraalada',
    'singular_title' => 'Ku dhaji',
    'lbl_image' => 'Sawirka',
    'lbl_name' => 'Magaca',
    'lbl_is_featured' => 'Sifaysan',
    'lbl_status' => 'Xaalada',
    'lbl_action' => 'Ficil',
    'lbl_information' => 'Xog',
    'lbl_short_description' => 'Sharaxaad Gaaban',
    'lbl_description' => 'Sharaxaada',
    'lbl_select_employee' => 'Dooro Shaqaale',
    'lbl_categories' => 'Qaybta',
    'lbl_type' => 'Nooca',
    'lbl_published_at' => 'Lagu daabacay',
    'seo' => 'Seo',
    'seo_meta_title' => 'Cinwaanka Seo Meta',
    'seo_meta_description' => 'Seo Meta Description',
    'seo_meta_open_graph_url' => 'Seo Meta Graph Url',
    'seo_meta_keywords' => 'Seo Meta Keywords',
    'seo_meta_open_graph_image' => 'Seo Meta Sawir Garaaf Furan'

 ];