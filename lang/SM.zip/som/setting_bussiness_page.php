<?php

return [
    'lbl_app'=>'App-ka',
    'lbl_doctor_app'=>'Dhakhtarka App',
    'lbl_user_app'=>'Isticmaalaha App',
    'lbl_contact_no'=>'Xiriirka No',
    'lbl_inquiry_email'=>'Iimayl weydiin',
    'lbl_site_description'=>'Sharaxaada goobta',
    'business_add'=>'Ganacsiga Ku dar',
    'lbl_shop_number'=>'Lambarka Dukaanka',
    'lbl_landmark'=>'lbl_landmark',
    'lbl_country'=>'Dalka',
    'lbl_state'=>'Gobolka',
    'lbl_city'=>'Magaalada',
    'lbl_postal_code'=>'Koodhka Boostada',
    'lbl_lat'=>'Latitude',
    'lbl_long'=>'Longitutide',
    'branding'=>'Calaamadaynta',
    'dark_mini_logo'=>'Madow Mini Logo',

];
