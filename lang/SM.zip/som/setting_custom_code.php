<?php

return [
    'lbl_css_name' => 'Koodhka Css ee gaarka ah (custom_css_block)',
    'lbl_js_name' => 'Koodhka Js Custom (custom_js_block)',
];
