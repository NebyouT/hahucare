<?php

return [
    'title' => 'Aagga dhoofinta',
    'lbl_name' => 'Magaca',
    'logistic' => 'Lojistikada',
    'cities' => 'Magaalooyinka',
    'state' => 'Gobolka',
    'country' => 'Dalka',
    'standard_delivery_charge' => 'Kharashka Bixinta Caadiga ah',
    'standard_delivery_time' => 'Waqtiga Gaarsiinta caadiga ah',
];
