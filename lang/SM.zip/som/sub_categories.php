<?php

return [
    'title' => 'Qaybaha hoose',

];
