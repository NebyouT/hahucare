<?php

return [
    'title' => 'Muhiimada',
    'singular_title' => 'Muhiim',
    'lbl_profile'=>'Profile',
    'lbl_height_CM'=>'dhererka cm',
    'lbl_weight_KG'=>'Miisaanka kg',
    'lbl_height_Inch'=>'dhererka Inish',
    'lbl_bmi'=>'BMI',
    'lbl_tbf'=>'TBF',
    'lbl_vfi'=>'VFI',
    'lbl_tbw'=>'TBW',
    'lbl_sm'=>'SM',
    'lbl_bmc'=>'BMC',
    'lbl_bmr'=>'BMR',
    'lbl_height_meter'=>'Mitirka Dhererka',




 ];
