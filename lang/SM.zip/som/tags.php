<?php

return [
    'title' => 'Tag',
];
