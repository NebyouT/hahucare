<?php

return [
    'title' => 'Dalacsiin',
    'singular_title' => 'Dalacsiin',
    'lbl_status'=>'heerka',
    'lbl_expired'=>'dhacay',
    'lbl_name' => 'Magaca',
    'lbl_action'=>'Ficil',
    'description' => 'Sharaxaada',
    'start_datetime'=>'Wakhtiga Taariikhda Bilawga',
    'end_datetime'=>'Wakhtiga Dhamaadka Taariikhda',
    'coupon_code'=>'Koodhka Koonka',
    'coupon_type'=>'Nooca Kuubka',
    'number_of_coupon'=>'Tirada kuuban',
    'percent_or_fixed'=>'Boqolkiiba ama go'an',
    'discount_percentage'=>'Boqolkiiba qiimo dhimis',
    'discount_amount'=>'Qadarka dhimista',
    'use_limit'=>'Isticmaalka Xadka',
    'coupon_title'=>'Kuubno',
    'user'=>'Isticmaale',
    'timezone'=>'TimeZone',
    'value'=>'Qiimaha',






];
