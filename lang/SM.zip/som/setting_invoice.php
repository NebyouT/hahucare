<?php

return [
    'lbl_order_prefix' => 'Dalbashada horgalaha',
    'lbl_order_starts' => 'Dalabka Bilaabma',
    'lbl_spacial_note' => 'Ogeysiis fog',
    'spacial_note'=>'Geli qoraalkaaga bannaan',

];
