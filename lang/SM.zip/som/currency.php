<?php

return [
    'title' => 'Wadamada',
    'lbl_edit' => 'Wax ka beddel lacagta',
    'lbl_add' => 'Ku dar Lacag Cusub',
    'lbl_currency_name' => 'Magaca Lacagta',
    'lbl_currency_symbol' => 'Astaanta Lacagta',
    'lbl_currency_code' => 'Xeerka Lacagta',
    'lbl_is_primary' => 'Waa Primary',
    'lbl_currency_position' => 'Booska Lacagta',
    'lbl_thousand_separatorn' => 'Kun Separatorn',
    'lbl_decimal_separator' => 'Kala saar tobanle',
    'lbl_number_of_decimals' => 'Tirada jajab tobanle',
    'lbl_ID' => 'Aqoonsiga',
    'lbl_action' => 'Ficil',
    'currency_format' => 'Habaynta Qaabka Lacagta',
    'primary_msg' => 'Waa inaad haysataa ugu yaraan hal lacag aasaasiga ah',
    'example'=>'Tusaale',
];
