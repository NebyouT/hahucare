<?php

return [
    'title' => 'Magaalooyinka',
    'singular_title' => 'Magaalada',
    'state_name' => 'Magaca Gobolka',
    'state' => 'Gobolka',
];
