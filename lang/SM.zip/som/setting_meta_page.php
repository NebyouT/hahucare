<?php

return [
    'lbl_site_name' => 'Magaca Goobta Meta (meta_site_name)',
    'lbl_description' => 'Sharaxaada Meta (sifada meta)',
    'lbl_keyword' => 'Keyword Meta (meta_keyword)',
    'lbl_image' => 'Sawirka Meta (meta_image)',
    'lbl_fb_app_id' => 'Meta Facebook App Id (meta_fb_app_id)',
    'lbl_twitter_site' => 'Meta Twitter Account Site (meta_twitter_site)',
    'lbl_twitter_creator' => 'Meta Twitter Akoonka Abuuraha (meta_twitter_creator)',
];
