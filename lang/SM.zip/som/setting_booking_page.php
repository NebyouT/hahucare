<?php

return [
    'lbl_name' => 'Booska Booska Duration',
];
