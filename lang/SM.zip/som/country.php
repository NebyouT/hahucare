<?php

return [
    'title' => 'Wadamada',
    'singular_title' => 'Dalka',
];
