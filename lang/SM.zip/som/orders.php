<?php

return [
    'title' => 'Dalabka',
];
