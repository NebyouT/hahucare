<?php

return [
    'lbl_primary' => 'Asal ahaan',
    'lbl_secondary' => 'Sare',
    'lbl_app_id' => 'Aqoonsiga App-ka',
    'lbl_security' => 'App Security',
];
