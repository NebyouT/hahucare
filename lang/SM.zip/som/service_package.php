<?php

return [
    'title' => 'Xidhmada Adeegga Adeegyada',
    'singular_title' => 'Xidhmada Adeegga Adeegga',
    'lbl_select_staff' => 'Dooro Shaqaale',
    'lbl_package_type' => 'Dooro Nooca Xidhmada',
    'lbl_category' => 'Qaybta',
    'lbl_sub_category' => 'Qaybta hoose',
    'lbl_select_service' => 'Dooro Adeeg',
    'lbl_start_at' => 'Ka bilow',
    'lbl_End At' => 'Dhammaad at',
    'lbl_price' => 'Qiimaha',
    'lbl_image' => 'Sawirka',
    'lbl_description' => 'Sharaxaada',
    'lbl_name' => 'Magaca',
    'lbl_status' => 'Xaalada',
];
