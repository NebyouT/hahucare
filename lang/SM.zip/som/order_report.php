<?php

return [
    'title' => 'Warbixinta Dalabka',
    'payment_status' => 'Heerka Lacag-bixinta',
    'paid' => 'La bixiyay',
    'unpaid' => 'Lacag la'aan',
    'delivery_status' => 'Heerka gaarsiinta',
    'order_placed' => 'Dalabka La Dhigay',
    'pending' => 'La sugayo',
    'processing' => 'Habaynta',
    'delivered' => 'la keenay',
    'cancelled' => 'La joojiyay',
];
