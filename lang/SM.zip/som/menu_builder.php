<?php

return [
    'lbl_title' => 'Ciwaanka',
    'lbl_add_menu' => 'Ku dar Menu',
    'lbl_edit_menu' => 'Wax ka beddel Menu',
    'lbl_icon' => 'Astaan',
    'lbl_menu_type' => 'Nooca Menu',
    'lbl_is_route' => 'App Router',
    'lbl_url' => 'URL',
    'lbl_target' => 'Ku fur tab',
    'lbl_status' => 'Xaalada',
    'lbl_disable' => 'Naafada',

];
