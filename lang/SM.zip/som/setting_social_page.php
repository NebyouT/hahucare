<?php

return [
    'lbl_fb_url' => 'URL bogga Facebook (facebook_url)',
    'lbl_twitter_url' => 'URL Profile Twitter (twitter_url)',
    'lbl_insta_url' => 'URL Account Instagram (instagram_url)',
    'lbl_linkedin_url' => 'LinkedIn URL (linkedin_url)',
    'lbl_youtube_url' => 'Youtube Channel URL (youtube_url)',
];
