<?php

return [
    'title' => 'Canshuur',
    'lbl_title' => 'Ciwaanka',
    'lbl_value' => 'Qiimaha',
    'lbl_select_type' => 'Dooro Nooca',
    'lbl_Type' => 'Nooca',
    'lbl_status' => 'Xaalada',
    'lbl_action' => 'Ficil',
    'lbl_module_type' => 'Nooca Module',
    'lbl_tax_type' => 'Nooca Cashuurta',
    'lbl_tax_category' => 'Qaybta Cashuuraha',

];
