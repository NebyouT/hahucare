<?php

return [
    'lbl_quick_booking' => 'Boos deg deg ah',
    'lbl_shared_link' => 'Xiriirinta la wadaago',
    'is_enable_all' => 'Dhammaan',
    'clinic' => 'Rugta caafimaadka',
    'lbl_verify'=>'Xaqiiji',
    'lbl_first_name'=>'Magaca Hore',
    'lbl_last_name'=>'Magaca Dambe',
    'lbl_phone_number'=>'Lambarka Taleefanka',
    'lbl_gender'=>'Jinsiga'
];
