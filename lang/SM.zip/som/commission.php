<?php

return [
    'lbl_title' => 'Ciwaanka',
    'lbl_value' => 'Qiimaha Komishanka',
    'lbl_commission_type' => 'Nooca Komishanka',
    'lbl_add_commission' => 'Kudar Komishanka',
    'lbl_edit_commission' => 'Wax ka beddel xogta guddiga',
    'lbl_sr_no' => 'Sr. Maya',
    'lbl_action' => 'Ficil',
    'lbl_commission_type' => 'Nooca Komishanka',
    'lbl_type' => 'Nooca',
];
