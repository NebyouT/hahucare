<?php

return [
    'title' => 'Kala duwanaanshaha',
    'singular_title' => 'Kala duwanaansho',
];
