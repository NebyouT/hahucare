<?php

return [
    'title' => 'Rugta caafimaadka',
    'singular_title' => 'Rugta caafimaadka',
    'lbl_profile_image' => 'Sawirka Xogta',
    'lbl_first_name' => 'Magaca Hore',
    'lbl_last_name' => 'Magaca Dambe',
    'lbl_Email' => 'iimaylka',
    'lbl_phone_number' => 'Lambarka Taleefanka',
    'lbl_gender' => 'Jinsiga',
    'lbl_status' => 'Xaalada',
    'lbl_verification_status' => 'Xaaladda Xaqiijinta',
    'lbl_blocked' => 'xannibay',
    'msg_verified' => 'La xaqiijiyay',
    'msg_unverified' => 'U Baahan In La Xaqiijiyo',
    'lbl_action' => 'Ficil',
    'lbl_date_of_birth'=>'Taariikhda Dhalashada',
    'google_blocked' => 'Maamulka rugta caafimaadka waa la xannibay',
    'google_unblocked' => 'Maamulka rugta caafimaadka waa laga saaray',
    'vendor_verify' => 'La Xaqiijiyay Admin Clinic',
    'vendor_status' => 'Clinic Admin Status Updated',
    'vendor_delete' => 'Maamulka Rugta Si Guul Ah Ayaa Loo Tirtiray',
    'lbl_select_system_service' => 'Dooro Adeegga Nidaamka',
    'new_vendor' => 'Maamulka rugta caafimaadka ayaa si guul leh u badbaadiyay',
    'update_vendor' => 'Maamulka kiliinikada si guul leh ayaa loo cusboonaysiiyay',
    'delete_vendor' => 'Maamulka rugaha ayaa si guul leh u tirtiray',

];
